﻿using System;
using System.Collections.Generic;

namespace AOC4
{
    class card
    {
        int[] WinningNumbers = new int[5];
        int[] YourNumbers = new int[8];

        public int originalIndex = -1;
        int Points = 0;
        int Pairs = 0;
        void CountPoints()
        {
            for (int Wi = 0; Wi < WinningNumbers.Length; Wi++)
            {
                for (int Yi = 0; Yi < YourNumbers.Length; Yi++)
                {
                    if (WinningNumbers[Wi] == YourNumbers[Yi])
                    {
                        PointsUp();
                    }
                }
            }

        }

        void PointsUp()
        {
            Pairs++;
            if (Points == 0)
            {
                Points = 1;
            }
            else
            {
                Points *= 2;
            }

        }

        public int getPoints() { return Points; }
        public int getPairs() { return Pairs; }

        public card(int[] Wn, int[] Yn)
        {
            WinningNumbers = Wn;
            YourNumbers = Yn;
            CountPoints();
        }

        public card(string inputText) {
            bool start = false;
            char prevchar = ' ';
            int tempNum = -1;

            List<int> Numbers = new List<int>();

            foreach (char c in inputText) {
                //start portion
                if (!start) {
                    if (c == ':') {
                        start = true;
                    }
                }else if (start) {
                    if (System.Char.IsDigit(c))
                    {

                        if (System.Char.IsDigit(prevchar))
                        {
                            tempNum = (tempNum * 10) + (c - '0');
                        }
                        else
                        {
                            tempNum = (c - '0');
                        }
                    }
                    else {
                        if (tempNum >= 0) { 
                            Numbers.Add(tempNum);
                            tempNum = -1;
                        }
                    }

                    if (c == '|') {
                        WinningNumbers = Numbers.ToArray();
                        Numbers = new List<int>();
                    }
                }

                prevchar = c;
            }
            Numbers.Add(tempNum);

            YourNumbers = Numbers.ToArray();

            CountPoints();
        }

        public card(card c) {
            WinningNumbers = c.WinningNumbers;
            YourNumbers = c.YourNumbers;
            originalIndex = c.originalIndex;
            Pairs = c.Pairs;
            Points = c.Points;
        }
        public void printCard()
        {
            Console.Write("card: ");
            foreach (int i in WinningNumbers)
            {
                Console.Write(i + " ");
            }

            Console.Write("| ");

            foreach (int i in YourNumbers)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine("");
        }
    }

    class fileReader {
        public List<string> readFile() {

            List<string> ret = new List<string>(); 
            string textFilePath = "cards.txt";
            string lineOfText = "";

            var filestream = new System.IO.FileStream(textFilePath,
                                              System.IO.FileMode.Open,
                                              System.IO.FileAccess.Read,
                                              System.IO.FileShare.ReadWrite);
            var file = new System.IO.StreamReader(filestream, System.Text.Encoding.UTF8, true, 128);


            while ((lineOfText = file.ReadLine()) != null)
            {
                ret.Add(lineOfText);
            }

            return ret;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            fileReader N = new fileReader();

            List<card> cards = new List<card>();
            int index = 0;
            foreach (string s in N.readFile()) {
                card c = new card(s);
                c.originalIndex =  index;
                cards.Add(c);
                index++;
            }

            List<List<card>> Allcards = new List<List<card>>();


            for (int i = 0; i < cards.Count; i++) { 
                Allcards.Add(new List<card>{ cards[i]});
            }

            List<card> originalcardsList = cards;

            cardrecursion();

            int count = 0;

            for (int i = 0; i < Allcards.Count; i++)
            {
                for (int j = 0; j < Allcards[i].Count; j++)
                {
                    //Console.Write((Allcards[i][j].originalIndex +1) + " ");
                    count++;
                }
                //Console.WriteLine("");
            }

            Console.WriteLine("Done! all cards total count: " + count);

            

            void cardrecursion()
            {
               for (int i = 0; i < Allcards.Count; i++) {
                    for (int j = 0; j < Allcards[i].Count; j++){

                        if (Allcards[i][j].getPairs() > 0) {
                            for (int k = 1; k < Allcards[i][j].getPairs()+1; k++) {
                                if (i + k < Allcards.Count){
                                    Allcards[i + k].Add(new card(Allcards[i + k][0]));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
